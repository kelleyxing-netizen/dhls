"""Author the software budget document, not the future venue software."""
import ast
import json
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

ROOT=Path('D:/aipj大项/dhls')
WORK=Path(__file__).resolve().parent
M=json.loads((ROOT/'docs/quotation/软件报价测算参数_20261024.json').read_text(encoding='utf-8'))
FONT='Microsoft YaHei'
# Reuse the previously visually verified typography helpers only.
source=ast.parse((WORK/'old_docx_helper.py').read_text(encoding='utf-8'))
names={'fonts','paragraph','heading','page_heading','table','hyperlink'}
exec(compile(ast.Module(body=[x for x in source.body if isinstance(x,ast.FunctionDef) and x.name in names],type_ignores=[]),str(WORK/'old_docx_helper.py'),'exec'))

_table=table
def table(doc,*args,**kwargs):
    t=_table(doc,*args,**kwargs)
    # Empty spacer paragraph marks inherit Word's normal line height. Removing
    # them avoids a blank continuation page after a full-height quotation table.
    spacer=doc.paragraphs[-1]
    assert not spacer.text
    spacer._p.getparent().remove(spacer._p)
    return t

def money(n):return f'{n:,.2f}'

def create():
    doc=Document();sec=doc.sections[0]
    sec.page_width=Cm(21);sec.page_height=Cm(29.7)
    sec.top_margin=Cm(1.55);sec.bottom_margin=Cm(1.55)
    sec.left_margin=Cm(1.8);sec.right_margin=Cm(1.8)
    sec.header_distance=Cm(.6);sec.footer_distance=Cm(.6)
    for st in doc.styles:
        if st.type in (1,2):st.font.name=FONT
        for b in list(st.element.iter(qn('w:pBdr'))):b.getparent().remove(b)
    doc.styles['Normal'].font.size=Pt(10)
    snap=OxmlElement('w:snapToGrid');snap.set(qn('w:val'),'0');doc.styles['Normal'].element.get_or_add_pPr().append(snap)
    p=doc.add_paragraph(style='Title');fonts(p.add_run('场馆排期与需求变更\nAI 数智化软件研发实施报价单'),21,True,'000000');p.paragraph_format.line_spacing=1.0;p.paragraph_format.space_after=Pt(6)
    paragraph(doc,f"报价编号 {M['number']}    日期 {M['date']}",size=9,color='62768A')
    paragraph(doc,'立项预算参考版  尚未开始软件研发',bold=True,color='9B491C')
    paragraph(doc,'拟建设面向场馆排期、资源冲突核对和需求变更协作的AI数智化软件。现有访谈演练、研究报告和流程图均属于前期调研。本报价仅估算后续需求复核、软件研发、测试部署及交付，不把旧成果当作已完成软件，也不重复向旧调研成果计费。',size=9.7)
    table(doc,['客户及商务信息','待确认内容','交付及预算口径','参考条件'],[
        ['客户单位及授权人','待填写','交付形态','单一组织内部Web工作台'],
        ['报价单位及负责人','待填写','建议周期','约16周 含约4周试运行'],
        ['报价有效期及签约日','待双方约定','币种及税费','人民币 税费待财务确认']
    ],[3.8,4.4,3.8,5.4],size=9.1)
    days=sum(x[3] for x in M['items']);base=days*M['daily_rate']
    model_month=M['requests_monthly']*(M['input_tokens_per_request']*M['input_price_per_million']+M['output_tokens_per_request']*M['output_price_per_million'])/1000000
    monthly=M['cloud_monthly']+M['backup_monthly']+model_month
    build_run=monthly*M['build_months'];year=monthly*M['operate_months'];later=M['maintenance_days']*M['daily_rate']
    heading(doc,'建议预算汇总')
    table(doc,['费用类别','参考金额 元','纳入口径'],[
        ['一期基础建设',money(base),f'{days}人日 × {M["daily_rate"]:,}元 每人日'],
        ['可选后续扩展','0.00','默认未选 另行确认'],
        ['建设及试点资源',money(build_run),'约4个月第三方资源 客户直付'],
        ['验收后12个月资源',money(year),'云 备份及模型调用 客户直付'],
        ['建设与验收后首运预算',money(base+build_run+year),'建设服务加两段资源 不含后续年度维保'],
        ['后续年度运行参考',money(later+year),'验收后第13至24个月 可选 不计入上行']
    ],[6.4,3.4,7.6],size=9.5)
    paragraph(doc,M['tax_note'],size=9,color='62768A')
    heading(doc,'建设服务款建议付款节点')
    payments=[]
    for rate in M['payment_rates'][:-1]:payments.append((Decimal(base)*Decimal(str(rate))).quantize(Decimal('.01'),rounding=ROUND_HALF_UP))
    payments.append(Decimal(base)-sum(payments))
    table(doc,['节点','建议比例','参考金额 元','付款触发条件'],[[x[0]+' '+x[2],f'{x[3]:.0%}',money(payments[i]),x[4]] for i,x in enumerate(M['milestones'])],[4.2,1.8,3.1,8.3],size=8.8)
    paragraph(doc,'建设分期仅含服务费，资源费直付。周期及含税总价以双方正式确认条件为准。',size=9)

    page_heading(doc,'一期软件研发实施明细')
    paragraph(doc,'建议统一服务单价1500元/人日，工作量为编制人的工作分解估算，不是实际研发工时或行业均价。既有调研只作为输入；S01仅估算新增真实需求复核。',size=9.2)
    rows=[[x[0],x[2],str(x[3]),money(M['daily_rate']),money(x[3]*M['daily_rate']),x[4]] for x in M['items']]
    table(doc,['编号','拟建模块或服务','人日','单价 元','金额 元','拟交付与验收边界'],rows,[.9,4,1.2,1.8,2.1,7.4],size=8.6)
    table(doc,['合计','人日','建设参考金额 元'],[['一期基础建设',str(days),money(base)]],[10.5,2.3,4.6],size=9.5)
    page_heading(doc,'一期范围假设与验收口径')
    table(doc,['报价边界','拟定范围'],M['scope'],[3.4,14],size=9.0)
    heading(doc,'建议验收口径')
    table(doc,['验收主题','双方需确认的口径'],[
        ['需求与样本基线','需求、字段、岗位、规则、数据范围及30条回放样本由双方签认。合成访谈不替代真实业务确认。'],
        ['功能与冲突规则','导入、来源、排期、变更、审批与审计按签认用例回放；有限样本符合预期不代表生产环境无漏报。'],
        ['AI效果与人工复核','确认候选字段、原文引用及不确定项进入人工队列。准确率、误报漏报阈值、标注方法及整改方案在需求阶段书面确认。'],
        ['软件交付','源码、文档、测试记录及培训齐备；关键流程阻断缺陷关闭，一般问题按双方认可计划处理后验收。']
    ],[3.4,14],size=9.0)
    paragraph(doc,'AI不代替审批人形成正式业务结论。权限不足、关键字段或版本无法确认、审批期间基线改变时应退回人工核验或重算；不默认通过。',size=9.1)

    page_heading(doc,'第三方资源与后续运行费用')
    paragraph(doc,'第三方费用按实际云账号和模型账号账单直付。应用及数据库、备份及日志的额度仅为预算预留，具体规格和供应商未确定；不含专用GPU、额外OCR或专业测评。',size=9.7)
    table(doc,['可修改假设','参考输入','计价说明'],[
        ['建设及试点资源期','4个月','按约16周预算取整 与验收后运行期不重叠'],
        ['验收后运行期','12个月','与建设及试点资源分段估算'],
        ['应用及数据库云资源','1200元/月','内部容量及费用假设 非云厂商正式报价'],
        ['备份 存储及日志','300元/月','预算预留 真实容量和保留期限待核'],
        ['月计费模型请求','10000次','含实际重试及工具往返 不等于业务申请单'],
        ['平均计费输入与输出','6000 / 1500 token','含提示词 历史和思考开销的预算假设'],
        ['输入与输出单价','0.8 / 8元 每百万token','P1官方档位示例 不是模型选型或锁价']
    ],[5.2,4.6,7.6],size=9.3)
    heading(doc,'资源费用测算')
    table(doc,['测算项目','参考金额 元','计算口径'],[
        ['模型调用 每月',money(model_month),'60百万输入×0.8 + 15百万输出×8'],
        ['云及备份 每月',money(M['cloud_monthly']+M['backup_monthly']),'1200 + 300'],
        ['第三方资源 每月',money(monthly),'模型调用 + 云及备份'],
        ['建设及试点4个月',money(build_run),'1668 × 4'],
        ['验收后12个月',money(year),'1668 × 12']
    ],[6.4,3.4,7.6],size=9.5)
    paragraph(doc,'P1按每次输入不超过32千token且输出超过0.2千token的在线价格演示。请求跨档、模型更换或账单范围变化时应更新单价。缓存折扣未计入；月度调用量、输入输出开销均未实测。',size=9.3)
    heading(doc,'验收后第13至24个月可选运维')
    table(doc,['费用项','参考金额 元','服务边界'],[
        ['远程日常运维',money(later),'12人日/年 × 1500元 健康检查 备份核验及问题处理'],
        ['同期12个月第三方资源',money(year),'按相同资源规模估算 客户直付'],
        ['后续年度运行预算',money(later+year),'不计入建设与验收后首运预算']
    ],[6.4,3.4,7.6],size=9.4)
    paragraph(doc,'验收后前12个月的约定缺陷修复已包含于建设费，不重复加收上述后续年度运维费。运维不含新功能、现场驻场和7×24值守；响应时段及服务上限另行签约。',size=9.3)

    page_heading(doc,'后续扩展与项目里程碑')
    paragraph(doc,'以下扩展默认不选，不计入一期基础建设或首运预算。正式启用前需明确范围、工作量、依赖条件及工期；第三方资源和许可证可能另行产生费用。',size=9.5)
    table(doc,['编号','可选建设范围','工作量','参考金额 元','范围条件'],[[x[0],x[1],str(x[2])+('项' if x[3] is None else '人日'),'待询价' if x[3] is None else money(x[2]*x[3]),x[4]] for x in M['options']],[.9,4.4,1.9,2.8,7.4],size=9.0)
    heading(doc,'建议建设计划')
    table(doc,['里程碑','建议时间','阶段交付结果'],[[x[0]+' '+x[2],x[1],x[4]] for x in M['milestones']],[4.8,2.5,10.1],size=9.1)
    paragraph(doc,'约16周从真实样本、客户评审人、环境及接入权限具备后排期。模块可并行推进，150人日不等于150个自然日。调研演练中“两名业务参与人员”的投入不等同于开发团队配置。',size=9.6)
    heading(doc,'需求变更与交付方式')
    paragraph(doc,'新增或减少范围时，记录原报价版本、变更内容、工作量、费用及排期影响，由客户和供应商授权人书面确认后执行。变更不得自动扩大数据使用或外部系统写回权限。',size=9.6)
    paragraph(doc,'拟交付约定范围源码、数据字典、部署与操作文档、测试及依赖清单、培训和验收记录。定制成果权属、第三方依赖及模型许可、账号归属和后续使用条件，由正式合同约定。旧调研工具的MIT文件不表示拟建软件已决定开源。',size=9.6)

    page_heading(doc,'商务条款 价格依据与双方确认')
    table(doc,['事项','待双方确认的建议约定'],[
        ['金额及税费',M['tax_note']],
        ['有效期及主体','客户、报价方、授权人员、报价有效期、签约日期及开票条件均待填写；本文件为立项预算参考。'],
        ['缺陷保障','验收后12个月修复约定范围内缺陷；新增需求、客户环境变化、第三方停服与现场服务另行约定。'],
        ['客户配合','提供合法授权的脱敏样本、规则标注人、云及模型账号和网络条件，按期评审。范围及数据条件未具备时应重新排期。'],
        ['数据和隐私','授权访问、脱敏只读、审计留痕和人工复核作为一期边界。真实个人及商业资料不进入公开仓库；留存及删除期限由双方签认。']
    ],[3.4,14],size=9.2)
    heading(doc,'价格及范围依据')
    for s in M['sources']:
        paragraph(doc,s[0]+' '+s[1],size=10,bold=True,after=3)
        paragraph(doc,s[3],size=9.1)
        if s[2].startswith('http'):hyperlink(doc,'查看官方模型说明',s[2])
        elif s[2]:paragraph(doc,'仓库位置 docs/source/discovery-report.md',size=9,color='62768A')
    paragraph(doc,'Excel为可调整测算版本，Word为当前参数的静态快照。修改Excel后须同步修订Word与版本号；模型价格只用于资源费演示，不能当作全部AI开发成本。',size=9.2)
    heading(doc,'双方确认')
    table(doc,['确认项','待填写'],[
        ['客户单位及授权代表','________________________________________'],
        ['报价单位及负责人','________________________________________'],
        ['定稿版本 有效期及含税总价','________________________________________'],
        ['签字及确认日期','________________________________________']
    ],[5.4,12],size=9.3)
    paragraph(doc,'本参考报价不表示软件已完成、场馆已锁档或双方已签订合同。',size=9,color='62768A')
    hp=sec.header.paragraphs[0];fonts(hp.add_run('DHLS  场馆排期与需求变更AI软件  立项预算参考'),8.2,color='62768A')
    fp=sec.footer.paragraphs[0];fp.alignment=WD_ALIGN_PARAGRAPH.RIGHT;fonts(fp.add_run(M['number']+'    第 '),8,color='62768A');f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');fp._p.append(f);fonts(fp.add_run(' 页'),8,color='62768A')
    for rf in doc.styles.element.iter(qn('w:rFonts')):
        for k in list(rf.attrib):del rf.attrib[k]
        for k in ('ascii','hAnsi','eastAsia','cs'):rf.set(qn('w:'+k),FONT)
    doc.core_properties.title=M['title'];doc.core_properties.author='DHLS';doc.core_properties.subject='拟建软件研发实施及运行预算 前期调研阶段'
    out=ROOT/'docs/reports/场馆排期与需求变更AI数智化软件_研发实施报价单_20261024.docx';doc.save(out)
    print(json.dumps({'file':str(out),'days':days,'base':base,'resources':build_run+year,'total':base+build_run+year},ensure_ascii=True))

if __name__=='__main__':create()
