import fs from 'node:fs/promises';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const work=path.dirname(fileURLToPath(import.meta.url));
const root='D:/aipj大项/dhls';
const mod=process.argv[process.argv.indexOf('--modules')+1];
const req=createRequire(path.join(mod,'..','dhls-runtime-loader.cjs'));
const {Workbook,SpreadsheetFile}=await import(pathToFileURL(req.resolve('@oai/artifact-tool')).href);
const m=JSON.parse(await fs.readFile(path.join(root,'docs/quotation/软件报价测算参数_20261024.json'),'utf8'));
const wb=Workbook.create();
const quote=wb.worksheets.add('报价总览'), build=wb.worksheets.add('建设明细'), run=wb.worksheets.add('运行费用'), scope=wb.worksheets.add('范围与条款');
const font='Microsoft YaHei',ink='#243B50',blue='#234A68',pale='#EDF3F8',yellow='#FFF1CE',money='#,##0.00;[Red](#,##0.00);0.00';
const set=(s,a,v)=>s.getRange(a).values=[[v]],fx=(s,a,f)=>s.getRange(a).formulas=[[f]];
function base(s,end,widths){s.showGridLines=false;const a=s.getRange(`A1:${String.fromCharCode(64+widths.length)}${end}`);a.format.font={name:font,size:11,color:ink};a.format.verticalAlignment='center';a.format.rowHeight=28;widths.forEach((w,i)=>s.getRangeByIndexes(0,i,end,1).format.columnWidthPx=w);}
function title(s,t){set(s,'A2',t);s.getRange('A2').format.font={name:font,size:16,bold:true,color:ink};s.getRange('A2').format.rowHeight=38;}
function head(s,a,v){s.getRange(a).values=[v];s.getRange(a).format={fill:blue,font:{name:font,size:11,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',verticalAlignment:'center',wrapText:true,rowHeight:34};}
function input(s,a){s.getRange(a).format.fill=yellow;s.getRange(a).format.font={name:font,size:11,color:'#935500'};}
function warn(s,a){s.getRange(a).conditionalFormats.add('containsText',{text:'待',format:{fill:'#FFF0E6',font:{color:'#9B491C',bold:true}}});}
function rowAmount(s,r,qty,price,select,dest){fx(s,`${dest}${r}`,`=IF(${select}${r}="否","",IF(${select}${r}="是",IF(COUNT(${qty}${r},${price}${r})=2,IF(MIN(${qty}${r},${price}${r})<0,"待核输入",ROUND(${qty}${r}*${price}${r},2)),"待询价"),"待选范围"))`);}
function subtotal(s,cell,range){fx(s,cell,`=IF(COUNTIFS(${range},"待询价")+COUNTIFS(${range},"待核输入")+COUNTIFS(${range},"待选范围")>0,"待补询价",SUM(${range}))`);}

base(build,43,[60,108,260,65,82,115,80,140,550,135]);title(build,'软件研发实施建设明细');set(build,'A4','拟建软件的预算工作分解；黄色可改，蓝灰色为计算或引用；不代表已经完成开发。');
set(build,'A5','统一人日参考单价 元');set(build,'F5',m.daily_rate);input(build,'F5');set(build,'I5','编制人建议价，非薪资或行业均价；已交付旧调研不重新收费。');
head(build,'A7:J7',['编号','阶段','拟建功能或服务','单位','工作量','单价 元','选用','金额 元','交付及验收边界','访谈依据']);
m.items.forEach((x,i)=>{const r=8+i;build.getRange(`A${r}:J${r}`).values=[[x[0],x[1],x[2],'人日',x[3],null,'是',null,x[4],x[5]]];fx(build,`F${r}`,'=$F$5');rowAmount(build,r,'E','F','G','H');build.getRange(`A${r}:J${r}`).format.rowHeight=66;build.getRange(`B${r}:D${r}`).format.wrapText=true;build.getRange(`I${r}:J${r}`).format.wrapText=true;if(i%2)build.getRange(`A${r}:J${r}`).format.fill='#F5F8FA';input(build,`E${r}`);input(build,`G${r}`);});
set(build,'C25','一期基础建设参考');subtotal(build,'H25','H8:H23');set(build,'C26','基础项已选人日');fx(build,'E26','=SUMIFS(E8:E23,G8:G23,"是")');set(build,'I26','取消任何基础项，须同步调整范围和验收基线；报价不自动确认系统仍然完整。');
head(build,'A29:J29',['编号','后续扩展','可选能力','单位','工作量','单价 元','选用','金额 元','范围边界 默认不计价','依据']);
m.options.forEach((x,i)=>{const r=30+i;build.getRange(`A${r}:J${r}`).values=[[x[0],'可选扩展',x[1],x[3]===null?'项':'人日',x[2],null,'否',null,x[4],'预算假设']];if(x[3]!==null)fx(build,`F${r}`,'=$F$5');input(build,`E${r}:G${r}`);if(x[3]!==null)build.getRange(`F${r}`).format.fill='#FFFFFF';rowAmount(build,r,'E','F','G','H');build.getRange(`A${r}:J${r}`).format.rowHeight=64;build.getRange(`C${r}:D${r}`).format.wrapText=true;build.getRange(`I${r}:J${r}`).format.wrapText=true;});
set(build,'C37','已选扩展参考合计');subtotal(build,'H37','H30:H35');set(build,'C39','本次建设服务合计');fx(build,'H39','=IF(COUNT(H25,H37)=2,SUM(H25,H37),"待补询价")');build.getRange('C39:J39').format.fill=pale;build.getRange('C39:J39').format.font={name:font,size:11,bold:true,color:ink};set(build,'C42','第三方资源和后续运维另列；无额外重复计提管理费，发票与税费口径待确认。');
build.getRange('E8:E35').setNumberFormat('0.00');build.getRange('F5:F35').setNumberFormat(money);build.getRange('H8:H39').setNumberFormat(money);['G8:G23','G30:G35'].forEach(a=>build.getRange(a).dataValidation={rule:{type:'list',values:['是','否']}});warn(build,'H8:H39');build.freezePanes.freezeRows(7);build.freezePanes.freezeColumns(3);

base(run,53,[290,200,28,900]);title(run,'第三方资源与后续运维估算');run.tabColor='#7895AC';
head(run,'A4:B4',['可修改测算参数','参考输入']);
const rv=[['建设及试点资源月数',m.build_months],['验收后运行月数',m.operate_months],['应用及数据库云资源 元/月',m.cloud_monthly],['备份 存储及日志 元/月',m.backup_monthly],['月计费模型请求数',m.requests_monthly],['每请求平均计费输入 token',m.input_tokens_per_request],['每请求平均计费输出 token',m.output_tokens_per_request],['输入单价 元/百万token',m.input_price_per_million],['输出单价 元/百万token',m.output_price_per_million]];
run.getRange('A5:B13').values=rv;input(run,'B5:B13');run.getRange('B5:B13').setNumberFormat('#,##0.00');set(run,'D5','建设期4个月为16周排期的预算取整；按实际启用月数调整，不与验收后12个月重复。');set(run,'D7','云、备份月费为容量预留假设，非云厂商正式配置报价；不含专用GPU。');set(run,'D9','请求数指计费API请求，包含重试及工具往返，不等于业务申请单数量。');set(run,'D11','计费输入输出应包含历史、提示词和思考开销；6000 / 1500为可改假设。');set(run,'D13','P1档位：每次输入≤32千token且输出>0.2千token；跨档须改单价。缓存折扣未计入。');
set(run,'A17','月输入 百万token');fx(run,'B17','=IF(COUNT(B9:B10)=2,IF(MIN(B9:B10)<0,"待核输入",B9*B10/1000000),"待补参数")');set(run,'A18','月输出 百万token');fx(run,'B18','=IF(COUNT(B9,B11)=2,IF(MIN(B9,B11)<0,"待核输入",B9*B11/1000000),"待补参数")');set(run,'A19','模型调用参考 元/月');fx(run,'B19','=IF(COUNT(B17:B18,B12:B13)=4,IF(MIN(B12:B13)<0,"待核输入",ROUND(B17*B12+B18*B13,2)),"待补参数")');
set(run,'A20','云及备份参考 元/月');fx(run,'B20','=IF(COUNT(B7:B8)=2,IF(MIN(B7:B8)<0,"待核输入",SUM(B7:B8)),"待补参数")');set(run,'A21','第三方资源合计 元/月');fx(run,'B21','=IF(COUNT(B19:B20)=2,SUM(B19:B20),"待补参数")');
set(run,'A23','建设及试点第三方资源');fx(run,'B23','=IF(COUNT(B5,B21)=2,IF(B5<0,"待核输入",ROUND(B5*B21,2)),"待补参数")');set(run,'A24','验收后运行第三方资源');fx(run,'B24','=IF(COUNT(B6,B21)=2,IF(B6<0,"待核输入",ROUND(B6*B21,2)),"待补参数")');set(run,'A25','两段第三方资源合计');fx(run,'B25','=IF(COUNT(B23:B24)=2,SUM(B23:B24),"待补参数")');set(run,'D23','客户按云和模型厂商账单直付，费用不包含在建设服务费或付款分期内。');set(run,'D25','未计额外OCR、搜索工具、短信、商业许可证、专业安全测评、异地差旅及驻场。');
head(run,'A28:B28',['验收后第13至24个月','可选维保估算']);set(run,'A29','年度运维支持 人日');set(run,'B29',m.maintenance_days);input(run,'B29');set(run,'A30','人日服务单价 元');fx(run,'B30',"='建设明细'!F5");set(run,'A31','年度运维参考服务费');fx(run,'B31','=IF(COUNT(B29:B30)=2,IF(MIN(B29:B30)<0,"待核输入",ROUND(B29*B30,2)),"待补参数")');set(run,'A32','同期12个月第三方资源');fx(run,'B32','=IF(ISNUMBER(B21),B21*12,"待补参数")');set(run,'A33','后续年度运行预算参考');fx(run,'B33','=IF(COUNT(B31:B32)=2,SUM(B31:B32),"待补参数")');set(run,'D29','验收后12个月缺陷修复已含建设费；此处是之后一年的可选日常维护，不重复加收免费保障期费用。');set(run,'D31','预算12人日/年；远程健康检查、备份核验和问题处理；不含新功能和7×24值守。');
run.getRange('B17:B33').setNumberFormat(money);warn(run,'B17:B33');run.getRange('A21:B25').format.rowHeight=34;run.getRange('A25:B25').format.fill=pale;
set(run,'A36','价格和来源 2026年10月24日核查');run.getRange('A36').format.font={name:font,size:13,bold:true,color:ink};
set(run,'A38','P1 豆包1.8官方模型说明');set(run,'D38',m.sources[1][2]);set(run,'D39',m.sources[1][3]);set(run,'A42','E1 预算假设');set(run,'D42',m.sources[2][3]);set(run,'A45','税费口径');set(run,'D45',m.tax_note);
for(const r of [5,7,9,11,13,23,25,29,31,38,39,42,45]){run.getRange(`D${r}`).format.wrapText=true;run.getRange(`D${r}`).format.rowHeight=r===39||r===42||r===45?70:48;}

base(scope,45,[235,1080]);title(scope,'建设范围 验收与商务条款');head(scope,'A4:B4',['一期报价边界','拟定范围与假设']);m.scope.forEach((x,i)=>{const r=i+5;scope.getRange(`A${r}:B${r}`).values=[x];scope.getRange(`A${r}:B${r}`).format.rowHeight=60;scope.getRange(`B${r}`).format.wrapText=true;if(i%2)scope.getRange(`A${r}:B${r}`).format.fill='#F5F8FA';});
const acceptance=[['需求基线','需求、流程、字段、角色、规则、数据范围及30条回放样本由双方签认。访谈演练不替代真实确认。'],['功能及规则','导入、来源、排期、变更、审批与审计按签认用例执行；有限回放样本符合预期不等于生产环境无漏报。'],['AI效果','验证字段候选、原文引用和不确定项入人工队列；准确率、误报漏报阈值及标注方法在需求阶段书面确认，当前不作无条件准确率承诺。'],['交付及缺陷','约定源码、文档、测试记录和培训齐备；关键流程阻断缺陷关闭，一般问题形成双方认可的处理计划后验收。']];
head(scope,'A17:B17',['验收主题','建议确认口径']);acceptance.forEach((x,i)=>{scope.getRange(`A${18+i}:B${18+i}`).values=[x];scope.getRange(`B${18+i}`).format.wrapText=true;scope.getRange(`A${18+i}:B${18+i}`).format.rowHeight=64;});
const terms=[['付款与税费','建设款建议30% / 40% / 20% / 10%，仅按已签认里程碑支付；第三方账单直付。'+m.tax_note],['需求变更','先记录原版本、变更内容、增加或减少工作量、费用和时间影响，双方授权人批准后执行。变更不自动取得外部系统写入权限。'],['保障与维护','验收后12个月修复已约定功能缺陷；新功能、客户环境变化、第三方停服及现场驻场另行约定。后续运维按单独协议选购。'],['源码及第三方权利','约定范围源码、数据字典、部署及操作文档、测试与依赖清单作为拟交付项；定制成果权属和第三方许可由正式合同确定，不据旧MIT文件推定软件开源。'],['客户配合与隐私','客户提供合法授权的脱敏样本、规则标注人、账号和环境，及时评审；真实个人及商业资料不进公开仓库。数据留存和删除期限另行签认。'],['有效期及签字','报价有效期、供应商主体、客户授权人、开票条件和签约日期均待填写；本文件是立项参考，不构成已签约或已研发事实。']];
head(scope,'A24:B24',['商务事项','待双方确认的建议条款']);terms.forEach((x,i)=>{scope.getRange(`A${25+i}:B${25+i}`).values=[x];scope.getRange(`B${25+i}`).format.wrapText=true;scope.getRange(`A${25+i}:B${25+i}`).format.rowHeight=i===0?100:72;});set(scope,'A33','L1 需求调查来源');set(scope,'B33','docs/source/discovery-report.md；fNN表示dlg-venue-schedule-fNN。原始访谈为合成演练，不能作为真实单量、工时或收益的测量数据。');scope.getRange('B33').format.wrapText=true;scope.getRange('A33:B33').format.rowHeight=60;set(scope,'A36','客户确认');set(scope,'A38','报价方确认');input(scope,'B36');input(scope,'B38');scope.freezePanes.freezeRows(4);

base(quote,39,[300,240,28,330,420]);title(quote,'场馆排期与需求变更 AI 软件报价');quote.tabColor=blue;set(quote,'A3',m.number+' | '+m.date);set(quote,'D3','立项参考 软件尚未开始研发');
set(quote,'A4','金额单位 人民币元 税费待财务确认');const costlabels=['一期基础建设','已选后续扩展','本次建设服务合计','建设及试点第三方资源','验收后12个月第三方资源','建设及验收后首运预算','后续年度运行参考 可选'];costlabels.forEach((x,i)=>set(quote,`A${i+6}`,x));
fx(quote,'B6',"='建设明细'!H25");fx(quote,'B7',"='建设明细'!H37");fx(quote,'B8',"='建设明细'!H39");fx(quote,'B9',"='运行费用'!B23");fx(quote,'B10',"='运行费用'!B24");fx(quote,'B11','=IF(COUNT(B8:B10)=3,SUM(B8:B10),"待补询价")');fx(quote,'B12',"='运行费用'!B33");quote.getRange('B6:B12').setNumberFormat(money);quote.getRange('A8:B8').format.fill=pale;quote.getRange('A11:B11').format.fill=pale;quote.getRange('A6:B12').format.rowHeight=36;warn(quote,'B6:B12');
fx(quote,'A10',`=IF(COUNT('运行费用'!B6)=1,"验收后"&'运行费用'!B6&"个月第三方资源","验收后运行资源 月数待补")`);
[['客户单位','待填写'],['报价单位','待填写'],['软件版本',m.version],['服务地区','上海 以合同交付方式为准'],['税费及开票','待财务确认'],['报价有效期','待双方约定']].forEach((x,i)=>{set(quote,`D${5+i}`,x[0]);set(quote,`E${5+i}`,x[1]);input(quote,`E${5+i}`);});set(quote,'A14','一期假设：1个场馆 30个账号 3种导入模板 约16周；详见范围与条款。');
head(quote,'A17:E17',['建设款建议节点','建议比例','','计划金额 元','付款条件']);
m.milestones.forEach((x,i)=>{const r=18+i;set(quote,`A${r}`,x[0]+' '+x[2]);set(quote,`B${r}`,x[3]);input(quote,`B${r}`);set(quote,`E${r}`,x[4]);quote.getRange(`E${r}`).format.wrapText=true;quote.getRange(`A${r}:E${r}`).format.rowHeight=60;const valid='AND(COUNT($B$18:$B$21)=4,MIN($B$18:$B$21)>=0,MAX($B$18:$B$21)<=1,ROUND(SUM($B$18:$B$21),6)=1,ISNUMBER($B$8))';fx(quote,`D${r}`,i<3?`=IF(${valid},ROUND($B$8*B${r},2),"待核比例或金额")`:`=IF(${valid},$B$8-SUM(D18:D20),"待核比例或金额")`);});quote.getRange('B18:B21').setNumberFormat('0%');quote.getRange('D18:D21').setNumberFormat(money);warn(quote,'D18:D21');
head(quote,'A25:E25',['拟定里程碑','建议时间','','交付结果','执行前提']);m.milestones.forEach((x,i)=>{const r=26+i;set(quote,`A${r}`,x[0]+' '+x[2]);set(quote,`B${r}`,x[1]);set(quote,`D${r}`,x[4]);set(quote,`E${r}`,i===0?'客户提供真实脱敏样本和规则标注人；范围书面确认。':'按确认基线实施；资料、审批或新增范围导致的排期变化另行确认。');quote.getRange(`A${r}:E${r}`).format.rowHeight=88;quote.getRange(`D${r}:E${r}`).format.wrapText=true;});
set(quote,'A32','预算使用说明');set(quote,'A34','建议价格可调整');set(quote,'B34','人日单价、模块工作量及运行费用均可修改。');set(quote,'D34','旧调研成果不重复计费；所有新增研发能力均为拟交付，当前无成品软件。');set(quote,'A36','总额和付款口径');set(quote,'B36','建设服务费与第三方费用分开，首运预算不包含可选后续年度运维。');set(quote,'D36','金额未默认套税率，定稿前确认含税总价；功能增删须同时修改范围和验收。');quote.getRange('B34:B36').format.wrapText=true;quote.getRange('D34:D36').format.wrapText=true;quote.getRange('A34:E36').format.rowHeight=62;

wb.recalculate();const expected=m.items.reduce((a,x)=>a+x[3]*m.daily_rate,0);assert.equal(expected,225000);assert.equal(quote.getRange('B8').values[0][0],expected);assert.equal(run.getRange('B19').values[0][0],168);assert.equal(quote.getRange('B11').values[0][0],251688);
set(build,'F5',1600);wb.recalculate();assert.equal(quote.getRange('B6').values[0][0],240000);set(build,'F5',m.daily_rate);
set(build,'G35','是');wb.recalculate();assert.equal(quote.getRange('B8').values[0][0],'待补询价');set(build,'F35',0);wb.recalculate();assert.equal(quote.getRange('B8').values[0][0],expected);set(build,'G35','否');set(build,'F35',null);
set(run,'B9',20000);wb.recalculate();assert.equal(run.getRange('B19').values[0][0],336);set(run,'B9',m.requests_monthly);
set(run,'B6',6);wb.recalculate();assert.equal(quote.getRange('A10').values[0][0],'验收后6个月第三方资源');assert.equal(quote.getRange('B10').values[0][0],10008);set(run,'B6',m.operate_months);
set(quote,'B18',0.4);wb.recalculate();assert.equal(quote.getRange('D18').values[0][0],'待核比例或金额');set(quote,'B18',m.payment_rates[0]);wb.recalculate();assert.equal(quote.getRange('D18').values[0][0]+quote.getRange('D19').values[0][0]+quote.getRange('D20').values[0][0]+quote.getRange('D21').values[0][0],expected);
const result=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!',options:{useRegex:true,maxResults:100}});console.log(result.ndjson);
const out=path.join(root,'docs/reports/场馆排期与需求变更AI数智化软件_研发实施报价单_20261024.xlsx');await(await SpreadsheetFile.exportXlsx(wb)).save(out);try{await fs.copyFile(out+'.inspect.ndjson',path.join(work,'export.inspect.ndjson'));await fs.unlink(out+'.inspect.ndjson');}catch(e){if(e.code!=='ENOENT')throw e;}
for(const [s,r,n] of [[quote,'A1:E37','summary'],[build,'A1:J26','build'],[build,'A29:J42','options'],[run,'A1:D33','run'],[run,'A36:D46','sources'],[scope,'A1:B21','scope'],[scope,'A24:B38','terms']]){const image=await wb.render({sheetName:s.name,range:r,scale:1.25,format:'png'});await fs.writeFile(path.join(work,n+'.png'),new Uint8Array(await image.arrayBuffer()));}
console.log(JSON.stringify({build:expected,months4:6672,months12:20016,total:251688,year2:38016,checks:'passed'}));
