"""Artifact generation and validation."""
