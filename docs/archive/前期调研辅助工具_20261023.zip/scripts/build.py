"""Run: python scripts/build.py check|report|flow|ai-flow|all."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from dhls.main import main

if __name__ == "__main__":
    raise SystemExit(main())
